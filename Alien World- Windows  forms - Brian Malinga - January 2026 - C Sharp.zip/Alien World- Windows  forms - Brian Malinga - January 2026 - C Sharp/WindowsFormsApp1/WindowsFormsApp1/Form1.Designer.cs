﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GameHero = new System.Windows.Forms.PictureBox();
            this.GameAlienTop = new System.Windows.Forms.PictureBox();
            this.GameAlienBottom = new System.Windows.Forms.PictureBox();
            this.GameGround = new System.Windows.Forms.PictureBox();
            this.GameScoreText = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.GameHero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameAlienTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameAlienBottom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameGround)).BeginInit();
            this.SuspendLayout();
            // 
            // GameHero
            // 
            this.GameHero.BackColor = System.Drawing.Color.Transparent;
            this.GameHero.Image = global::WindowsFormsApp1.Properties.Resources.guide;
            this.GameHero.Location = new System.Drawing.Point(70, 162);
            this.GameHero.Name = "GameHero";
            this.GameHero.Size = new System.Drawing.Size(52, 63);
            this.GameHero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GameHero.TabIndex = 0;
            this.GameHero.TabStop = false;
            // 
            // GameAlienTop
            // 
            this.GameAlienTop.BackColor = System.Drawing.Color.Transparent;
            this.GameAlienTop.Image = global::WindowsFormsApp1.Properties.Resources.pixel_0092_4023341709;
            this.GameAlienTop.Location = new System.Drawing.Point(591, 27);
            this.GameAlienTop.Name = "GameAlienTop";
            this.GameAlienTop.Size = new System.Drawing.Size(99, 119);
            this.GameAlienTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GameAlienTop.TabIndex = 1;
            this.GameAlienTop.TabStop = false;
            // 
            // GameAlienBottom
            // 
            this.GameAlienBottom.BackColor = System.Drawing.Color.Transparent;
            this.GameAlienBottom.Image = global::WindowsFormsApp1.Properties.Resources.pixel_0056_900920138;
            this.GameAlienBottom.Location = new System.Drawing.Point(428, 281);
            this.GameAlienBottom.Name = "GameAlienBottom";
            this.GameAlienBottom.Size = new System.Drawing.Size(119, 157);
            this.GameAlienBottom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GameAlienBottom.TabIndex = 2;
            this.GameAlienBottom.TabStop = false;
            // 
            // GameGround
            // 
            this.GameGround.BackColor = System.Drawing.Color.Transparent;
            this.GameGround.Location = new System.Drawing.Point(-1, 413);
            this.GameGround.Name = "GameGround";
            this.GameGround.Size = new System.Drawing.Size(807, 50);
            this.GameGround.TabIndex = 3;
            this.GameGround.TabStop = false;
            // 
            // GameScoreText
            // 
            this.GameScoreText.AutoSize = true;
            this.GameScoreText.BackColor = System.Drawing.Color.Transparent;
            this.GameScoreText.Font = new System.Drawing.Font("Cooper Black", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GameScoreText.Location = new System.Drawing.Point(12, 6);
            this.GameScoreText.Name = "GameScoreText";
            this.GameScoreText.Size = new System.Drawing.Size(157, 40);
            this.GameScoreText.TabIndex = 4;
            this.GameScoreText.Text = "Score: 0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Magneto", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Alien World";
            // 
            // GameTimer
            // 
            this.GameTimer.Enabled = true;
            this.GameTimer.Interval = 20;
            this.GameTimer.Tick += new System.EventHandler(this.GameTimerEvent);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.GameScoreText);
            this.Controls.Add(this.GameGround);
            this.Controls.Add(this.GameAlienBottom);
            this.Controls.Add(this.GameAlienTop);
            this.Controls.Add(this.GameHero);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Alien World Game";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GameKeysDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.GameKeysUp);
            ((System.ComponentModel.ISupportInitialize)(this.GameHero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameAlienTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameAlienBottom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameGround)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox GameHero;
        private System.Windows.Forms.PictureBox GameAlienTop;
        private System.Windows.Forms.PictureBox GameAlienBottom;
        private System.Windows.Forms.PictureBox GameGround;
        private System.Windows.Forms.Label GameScoreText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer GameTimer;
    }
}


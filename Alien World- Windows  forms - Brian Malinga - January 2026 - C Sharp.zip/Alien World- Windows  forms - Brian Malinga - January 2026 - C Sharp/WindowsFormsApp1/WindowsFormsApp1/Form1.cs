﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int AlienSpeed = 7;
        int Gravity = 7;
        int Score = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void GameTimerEvent(object sender, EventArgs e)
        {
            GameHero.Top += Gravity;
            GameAlienBottom.Left -= AlienSpeed;
            GameAlienTop.Left -= AlienSpeed;
            GameScoreText.Text = "Score:" + Score;


            if(GameAlienBottom.Left < -150)
            {
                GameAlienBottom.Left = 916;
                Score++;
            }

            if (GameAlienTop.Left < -180)
            {
                GameAlienTop.Left = 980;
                Score++;
            }



            if (GameHero.Bounds.IntersectsWith(GameAlienBottom.Bounds) ||

               GameHero.Bounds.IntersectsWith(GameAlienTop.Bounds) ||

               GameHero.Bounds.IntersectsWith(GameGround.Bounds) ||  GameHero.Top < -25

               )
            {
                EndGame();
            }


            if (Score > 10)
            {
                AlienSpeed = -15;
            }

        }

        private void GameKeysDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                Gravity = -7;
            }
        }

        private void GameKeysUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                Gravity = 7;
            }
        }

        private void EndGame()
        {
            GameTimer.Stop();
            GameScoreText.Text += " Game over!!!";
        }
    }
}
